export interface ProjectOffer {
  id: string;
  name: string;
  offerAmount: number;
}