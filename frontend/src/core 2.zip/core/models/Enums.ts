export enum UserGroup {
    User = 'User',
    Admin = 'Admin'
  }
  
  export enum UserState {
    Active = 'Active',
    Locked = 'Locked'
  }
  