export interface EmailLoginRequest {
    emailId: string;
    password: string;
  }
