export interface AuthRequest {
    refreshToken: string;
  }