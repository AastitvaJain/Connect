import { request } from './request';
import type { InventoryRequest } from '../models/requests/InventoryRequest';
import type { SoldInventoryDto, NewInventoryDto } from '../models/InventoryDto';

// POST /get/new-inventory
export const getNewInventory = (data: InventoryRequest) =>
  request<{ newInventories: { totalCount: number; pageNumber: number; pageSize: number; totalPages: number; items: NewInventoryDto[] } }>(
    {
      method: 'POST',
      url: '/get/new-inventory',
      data,
      withAuth: true
    }
  );

// POST /get/sold-inventory
export const getSoldInventory = (data: InventoryRequest) =>
  request<{ soldInventories: { totalCount: number; pageNumber: number; pageSize: number; totalPages: number; items: SoldInventoryDto[] } }>(
    {
      method: 'POST',
      url: '/get/sold-inventory',
      data,
      withAuth: true
    }
  );
