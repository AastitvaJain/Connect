export interface ChannelPartnerDto {
    id: string;
    name: string;
  }
  
  export interface ProjectNameDto {
    projectName: string;
  }
  